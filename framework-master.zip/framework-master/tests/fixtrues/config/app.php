<?php

return [
    'foo' => [
        'bar' => 'sparkPHP',
    ],
];